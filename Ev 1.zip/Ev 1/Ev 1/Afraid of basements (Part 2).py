with open("Instructions Afraid of Basements.txt", "r") as data:
    instructions = data.read()

position = 0
floor = 0
for steps in instructions:
    if floor == -1:
        print(position)
        break
    else:
        if steps == "(":
                floor += 1
        elif steps == ")":
                floor -= 1
        position += 1
    