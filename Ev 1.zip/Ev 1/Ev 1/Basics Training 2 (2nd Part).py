user_value = int(input("Enter a number: "))

result = 0

for i in range(1, 13):
    result = user_value * i
    print(f"{user_value} * {i} = {result}")