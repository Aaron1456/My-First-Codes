firstSet = {1, 2, 3, 4, 5}
secondSet = {4, 5, 6, 7, 8}

set_union = firstSet.union(secondSet)
set_intersection = firstSet.intersection(secondSet)
set_difference = firstSet - secondSet

firstSet.add(6)

firstSet = list(firstSet)
firstSet[3:]
firstSet = set(firstSet)