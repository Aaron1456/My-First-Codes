filename = input("Enter the name of the file to save content: ")

if filename == "":
    print("Filename cannot be empty.")
else:
    try:
        file = open(filename, "w")
        print("Type your content below. Type 'finish' to stop.")

        word_count = 0

        while True:
            line = input()
            if line.lower() == "finish":
                break
            file.write(line + "\n")
            word_count += len(line.split())

        file.close()
        print("File saved successfully.")
        print("Total words written:", word_count)

    except:
        print("Something went wrong while working with the file.")