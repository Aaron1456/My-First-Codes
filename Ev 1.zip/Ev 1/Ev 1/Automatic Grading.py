def calculate_grade(marks):
    average = sum(marks) / len(marks)
    if 90 <= average <= 100:
        grade = 'A'
    elif 80 <= average < 90:
        grade = 'B'
    elif 70 <= average < 80:
        grade = 'C'
    elif 60 <= average < 70:
        grade = 'D'
    else:
        grade = 'F'
    return average, grade

def print_report(name, marks):
    average, grade = calculate_grade(marks)
    print(f"{name} -> Average: {average:.1f}, Grade: {grade}")

students = {
    "Alice": [],
    "Bob": [],
    "Charlie": []
}

for name in students:
    print(f"Enter marks for {name}:")
    while len(students[name]) < 3:
        try:
            mark = float(input(f"  Mark {len(students[name]) + 1}: "))
            if 0 <= mark <= 100:
                students[name].append(mark)
            else:
                print("  Please enter a number between 0 and 100.")
        except ValueError:
            print("  Invalid input. Please enter a numeric value.")

print("\nStudent Reports:")
for name, marks in students.items():
    print_report(name, marks)