while True:
    try:
        num1 = float(input("Enter the first number: "))
        
        num2 = float(input("Enter the second number: "))
        
        operator = input("Enter an operator (+, -, *, /): ")
        if operator not in ['+', '-', '*', '/']:
            raise ValueError("Operator must be one of +, -, *, /.")
        
        if operator == '+':
            result = num1 + num2
        elif operator == '-':
            result = num1 - num2
        elif operator == '*':
            result = num1 * num2
        elif operator == '/':
            if num2 == 0:
                raise ZeroDivisionError("Cannot divide by zero.")
            result = num1 / num2
        
    except ValueError as i:
        print("Please enter a valid number or operator.")
        print(f"Error: {i}")
    except ZeroDivisionError as o:
        print("Cannot divide by zero.")
        print(f"Error: {o}")
    else:
        print(f"{num1} {operator} {num2} = {result}")
    finally:
        print("Done.")
    
    again = input("Press 'q' to end or press any key to continue: ").lower()
    if again == 'r':
        break