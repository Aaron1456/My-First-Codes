user_num = int(input("Enter a number: "))
value = 0

for i in range(user_num):
    value = value + i

value = value + user_num    
print(value)