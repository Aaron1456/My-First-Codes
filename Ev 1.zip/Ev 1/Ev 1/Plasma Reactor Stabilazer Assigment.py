temperature = int(input("Enter the temperature: "))
cubicMetersOfWater = int(input("Enter the Cubic Meters of Water: "))
result = temperature+cubicMetersOfWater
balancedNumber = result/2
finalResult = balancedNumber*balancedNumber
print(balancedNumber)
print(finalResult)
