numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


print(numbers[0], numbers[-1])

print(numbers[0:4])

print(numbers[::-1])

numbers[4] = 11

numbers.append(12)

print(numbers)