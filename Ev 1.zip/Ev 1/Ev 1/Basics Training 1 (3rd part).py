user_number = int(input("Enter a number: "))

if user_number > 0:
    print("The number is positive")

elif user_number < 0:
    print("The number is negative")

else:
    print("The number is zero")