num = int(input("Enter a number: "))

if num < 0:
    print("It is negative")

elif num > 0:
    print("It is positive")

else:
    print("According to my calculations, your number is 0")