for i in range(1,101):
    if i % 3 == 0:
        print("Three")
    
    elif i % 5 == 0:
        print("Five")
    
    elif i % 15 == 0:
        print("Fifteen")
    
    else:
        print(i)