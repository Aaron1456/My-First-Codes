print("Welcome to DAC (Dominican All Chicken)")
reservations = ["","Profe Braulio", "Mr. Chen", "Estimado Barinas", "Alexander da Great", "Disco Director Mr. Juan"]

menu_food = {"End Order": 0,
             1: "Fried Chicken: 100",
             2: "Baked Chicken: 100",
             3: "Roasted Chicken: 125",
             4: "Grilled Chicken: 200"}

menu_drink = {"End Order": 0,
              1: "Lemon Juice: 75",
              2: "Strawberry Juice: 50",
              3: "Organge Juice: 75",
              4: "Tamarind Juice: 100"}

menu_dessert = {"End Order": 0,
                1: "Flan: 100",
                2: "Cheese Cake: 100",
                3: "Brownie: 75",
                4: "Ice Cream: 100"}

user_order = []

food_prices = {menu_food[1]: 100, menu_food[2]: 100, menu_food[3]: 125, menu_food[4]: 200}
drink_prices = {menu_drink[1]: 75, menu_drink[2]: 50, menu_drink[3]: 75, menu_drink[4]: 100}
dessert_prices = {menu_dessert[1]: 100, menu_dessert[2]: 100, menu_dessert[3]: 75, menu_dessert[4]: 100}

run_Menu_food = False
run_Menu_drink = False
run_Menu_dessert = False
finish_order_food = False
finish_order_drink = False
finish_order_dessert = False


user_value = (input("Do you have an reservation? Yes or No: ")).lower()
if user_value == "yes":
    print(reservations)
    reservation_number = int(input("Enter in number order which one is you. Type the order as it is shown. Type 0 if you dont have one: "))

    match reservation_number:
        case 1|2|3|4|5: run_Menu_food = True

        case 0: print("See you later")

        case _: print("There is no reservation registered. Please restart your order")

    if run_Menu_food == True:
        print(f"Welcome, {reservations[reservation_number]}")
        while run_Menu_food == True:
            print(menu_food)
            foodOrder = int(input("What food would you like to order? Type the number shown (Type 0 to end your order): "))
            match foodOrder:
                case 1|2|3|4: user_order.append(menu_food[foodOrder])

                case 0: 
                    run_Menu_food = False
                    finish_order_food = True

                case _: print("Error, the product ordered is not on the list. Try again")

    if finish_order_food == True:
        run_Menu_drink = True

        while run_Menu_drink == True:
            print(menu_drink)
            foodOrder = int(input("What drink would you like to order? Type the number shown (Type 0 to end your order): "))
            match foodOrder:
                case 1|2|3|4: user_order.append(menu_drink[foodOrder])

                case 0:
                    run_Menu_drink = False
                    finish_order_drink = True

                case _: print("Error, the poduct ordered is not on the list. Try again")

    if finish_order_drink == True:
        run_Menu_dessert = True

        while run_Menu_dessert == True:
            print(menu_dessert)
            foodOrder = int(input("What dessert would you like to order? Type the number shown (Type 0 to end your order): "))
            match foodOrder:
                case 1|2|3|4: user_order.append(menu_dessert[foodOrder])

                case 0: 
                    run_Menu_dessert = False
                    finish_order_dessert = True

                case _: print("Error, the product ordered is not on the list. Try again")
         
            total = 0
            ITbis = 0.18
         

            for item in user_order:
                if item in food_prices:
                    total += food_prices[item]
                elif item in drink_prices:
                    total += drink_prices[item]
                elif item in dessert_prices:
                    total += dessert_prices[item]

            tax = total * ITbis
            final_total = tax + total

        print("Your order summary:")
        for item in user_order:
            print(f" {item}") 
        print(f"Subtotal: RD${total}")
        print(f"ITBIS: {tax}")
        print(f"Total to pay: RD${final_total}")
        run_money_loop = True

        while run_money_loop == True:

            cardORcash = input("Will you pay with card or cash? Type 0 if you wish to retire your order. Then we will retire your order: ").lower()

            if cardORcash == "card":
                balance = int(input("What is your card balance?: "))
                if balance >= final_total:
                    balance_left = balance - final_total
                    print(f"Your balance of your card is now {balance_left}")
                    print(f"Thanks for ordering here in DAC, {reservations[reservation_number]}! Enjoy and please come back again!")
                    run_money_loop = False

                elif balance < final_total:
                    print("That is not enough")
                    print("Enter another balance or pay with cash")

            elif cardORcash == "cash":
                balance = int(input("Enter the amount of cash: "))
                denominations = [2000, 1000, 500, 200, 100, 50, 25, 10, 5, 1]
                if balance > final_total:
                    change = balance - final_total

                    print(f"Here is your change: {change}")
                    for i in denominations:
                        count = change // i
                        if count:
                            print(f"{i}: {count}")
                            change -= i * count
                    
                    
                    run_money_loop = False
            
                elif balance == final_total:
                    run_money_loop = False

                else:
                    print("That is not enough")
                    print("Enter another amount or pay with card")
            
            elif cardORcash == 0:
                print("Your order has been sucessfully retired")
                break

            else:
                print("There was a typo or we don't accept that type of payment. Please try again")
        
        run_tip_loop = True
        while run_tip_loop == True:
            user_tip = input("You you want to add a tip to make our service even better?: ").lower()

            if user_tip == "yes":
                tip_amount = int(input("Tip amount: "))
                if cardORcash == "card":
                    if tip_amount <= balance:
                        balance_left -= tip_amount
                        print(f"Your card balance is now {balance_left}")
                        print(f"Thanks for the extra reward, {reservations[reservation_number]}! We promise to improve our services")
                        print(f"Thanks for ordering here in DAC, {reservations[reservation_number]}! Enjoy and please come back again!")
                        run_tip_loop = False

                    

                    else:
                        print("Thanks for trying to give us a tip, but your card balance does not reach budget")
                        try_again = input("Do you wish to try again to enter a tip?: ").lower()
                        if try_again == "no":
                            print(f"Thanks for ordering here in DAC, {reservations[reservation_number]}! Enjoy and please come back again!")
                            run_tip_loop = False

                        elif try_again == "yes":
                            run_tip_loop = True

                        else:
                            print("Did you mean 'yes' or 'no'? Please try again")


            elif user_tip == "no":
                print(f"Thanks for ordering here in DAC, {reservations[reservation_number]}! Enjoy and please come back again!")
                run_tip_loop = False


            else:
                print("Sorry, it seems that there was a typo, please try again by typing 'yes' or 'no'")

else:
    print("Sorry, this is an only reservation restaurant. Please retire")