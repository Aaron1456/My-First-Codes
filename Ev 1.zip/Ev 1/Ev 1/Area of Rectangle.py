length = int(input("Enter the length: "))
width = int(input("Enter the width: "))
result = length * width
print(result)