import time

def user_input_angle(number):
    while True:
        try:
            angle = int(input(f"Enter angle {number}: "))
            if angle <= 0:
                print("Side must be a positive number.")
            else:
                return angle
        except:
            print("Invalid input. Please enter a number.")

def is_triangle(a, b, c):
    angles = sorted([a, b, c])
    return angles[0] + angles[1] > angles[2]

a = user_input_angle("A")
b = user_input_angle("B")
c = user_input_angle("C")

print("Calculating...")
time.sleep(1.5)

if is_triangle(a, b, c):
    print(f"Real triangle with sides {a}, {b}, {c}")
else:
    print(f"Not a real triangle with sides {a}, {b}, {c}")