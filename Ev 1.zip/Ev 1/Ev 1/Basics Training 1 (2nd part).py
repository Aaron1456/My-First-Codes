firstNum = int(input("Enter a number: "))
secondNum = int(input("Enter another number: "))
thirdNum = int(input("Enter another number: "))

if firstNum > secondNum and firstNum > thirdNum:
    print(f"The biggest number is {firstNum}")

elif firstNum == secondNum and firstNum == thirdNum:
    print("All numbers are equal")

elif secondNum > firstNum and secondNum > thirdNum:
    print(f"The biggest number is {secondNum}")

else:
    print(f"The biggest number is {thirdNum}")