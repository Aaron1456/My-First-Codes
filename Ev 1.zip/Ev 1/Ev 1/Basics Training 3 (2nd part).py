countries = ("United States", "Canada", "Venezuela", "China", "Dominican Republic", "Japan")

print(countries[0], countries[3])

print(countries[3:])

print(countries[-2:])

# It doesnt work because tuples cant be modified
# countries[0] = ("Mexico")
# print(countries)

countries = list(countries)
countries.append("Mexico")
countries = tuple(countries)

print(countries)