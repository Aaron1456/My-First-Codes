hour = int(input("Enter a hour in the 12-hour "))
am_or_pm = input("am or pm: ")

while True:
    try:
        hpur = int(input("Enter a hour in the 12-hour: "))
        am_or_pm = input("am or pm. Do not use dots: ").lower()

        if hour > 1 or hour < 12:
            print("Please enter a number from 1 to 12. Try again")
            continue

        if am_or_pm != "am" or am_or_pm != "pm":
            print("am or pm. Try again")
            continue

        hour24 = hour

        if am_or_pm == "am":
            if hour != 12:
                hour24 += 12

        elif am_or_pm == "pm":
            if hour == 12:
                hour24 = 0

        print(f"The input converted to 24-hour format is: {hour24:02d}")

    except ValueError:
        print("Error. Could not convert input")
        print("Please try again correctly")