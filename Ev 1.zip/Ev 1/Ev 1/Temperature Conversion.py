celsius = int(input("Enter the temperature in celsius to convert it to fahrenheit: "))
fahrenheit = 9/5*celsius+32
print(f"The temperature in fahrenheit is {fahrenheit}")