grades = {"Alice": 85, "Bob": 90, "Charlie": 78, "Diana": 92, "Ethan": 88, "Fiona": 95}

key = "Bob"
index_key = list(grades).index(key)

grades["Adam"] = 100

grades["Charlie"] = 82

print(grades)