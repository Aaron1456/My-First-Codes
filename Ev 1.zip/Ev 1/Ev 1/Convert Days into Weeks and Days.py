week = 7
days = int(input("Enter the numbers of days: "))
numOfWeeks = days//week
daysLeft = days%week
print(f"There are {numOfWeeks} and {daysLeft} days left")