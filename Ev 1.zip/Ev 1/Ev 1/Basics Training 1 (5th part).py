user_value = input("Enter a day of the week: ").lower()

match user_value:
    case "monday":
        print("Its a weekday")

    case "tuesday":
        print("Its a weekday")

    case "wednesday":
        print("Its a weekday")

    case "thursday":
        print("Its a weekday")

    case "friday":
        print("Its a weekday")

    case "saturday":
        print("Its a weekend")

    case "sunday":
        print("Its a weekend")

    case _:
        print("Bro, write a day of the week. That ain't a day of the week.")