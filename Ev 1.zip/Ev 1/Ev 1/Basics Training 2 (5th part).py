password = "Peanut Butter"
user_tryPassword = input("Enter your password: ")

while True:
    if user_tryPassword == password:
        print("Correct")
        break
    
    else:
        user_tryPassword = input("Incorrect. Try again: ")