user_value = int(input("Enter a even number: "))
user_value = user_value + 1

for i in range(user_value):
    if i % 2 == 0:
        print(i)