firstNum = int(input("Enter a number: "))
secondNum = int(input("Enter another number: "))

if firstNum > secondNum:
    print(f"The biggest number is {firstNum}")

elif firstNum == secondNum:
    print("Both numbers are equal")

else:
    print(f"The biggest number is {secondNum}")