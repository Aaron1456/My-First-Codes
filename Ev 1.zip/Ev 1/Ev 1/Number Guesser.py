import random
secret_number = random.randint(1,50)
attempts = 5

while True:
    
    try:
        if attempts > 0:
            user_guess = float((input("Enter your guess number: ")))
            if user_guess == secret_number:
                print("Correct!")
                break
            elif user_guess > secret_number:
                print("Too high!")
            elif user_guess < secret_number:
                print("Too low!")

            attempts -= 1
            print(f"Attempts remaining: {attempts}")

        else:
            print("Attempts over")
            print(f"The secret number was {secret_number}")
            break

    except ValueError as e:
        print("Enter a valid number")