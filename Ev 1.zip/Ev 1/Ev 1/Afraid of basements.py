with open("Instructions Afraid of Basements.txt", "r") as data:
    instructions = data.read()
floor = 0

for steps in instructions:
    if steps == "(":
        floor += 1
    elif steps == ")":
        floor -= 1

print(f"{floor}")
    