user_value = int(input("Enter a number to start the countdown: "))

import time

while user_value > 0:
    print(user_value)
    user_value = user_value - 1
    time.sleep(1)
    
print(0)
time.sleep(0.2)
print("Coundown finished")